﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using System.Diagnostics;
using System.Configuration;
using Newtonsoft.Json;


using System.Globalization;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Web;

namespace ChatMessageProcessor
{
    internal class SentimentEventProcessor : IEventProcessor
    {
        private readonly string _chatTopicPath = ConfigurationManager.AppSettings["chatTopicPath"];
        private readonly string _connectionString = ConfigurationManager.AppSettings["eventHubConnectionString"];
        private readonly string _destinationEventHubName = ConfigurationManager.AppSettings["destinationEventHubName"];
        private readonly string _textAnalyticsBaseUrl = ConfigurationManager.AppSettings["textAnalyticsBaseUrl"];
        private readonly string _textAnalyticsAccountKey = ConfigurationManager.AppSettings["textAnalyticsAccountKey"];

        private Stopwatch _checkpointStopWatch;
        private TopicClient _topicClient;
        private EventHubClient _eventHubClient;

        async Task IEventProcessor.CloseAsync(PartitionContext context, CloseReason reason)
        {
            Console.WriteLine("Processor Shutting Down. Partition '{0}', Reason '{1}'.", context.Lease.PartitionId, reason);
            if (reason == CloseReason.Shutdown)
            {
                await context.CheckpointAsync();
            }
        }

        Task IEventProcessor.OpenAsync(PartitionContext context)
        {
            Console.WriteLine("SimpleEventProcessor initialized. Partition '{0}', Offset '{1}'", context.Lease.PartitionId, context.Lease.Offset);
            this._checkpointStopWatch = new Stopwatch();
            this._checkpointStopWatch.Start();

            this._topicClient = TopicClient.CreateFromConnectionString(_connectionString, _chatTopicPath);
            this._eventHubClient = EventHubClient.CreateFromConnectionString(_connectionString, _destinationEventHubName);

            return Task.FromResult<object>(null);
        }

        class MessageType
        {
            public string message;
            public DateTime createDate;
            public string username;
            public string sessionId;
            public string messageId;
            public double score;
        }

        async Task IEventProcessor.ProcessEventsAsync(PartitionContext context, IEnumerable<EventData> messages)
        {
            foreach (var eventData in messages)
            {
                try
                {
                    var eventBytes = eventData.GetBytes();
                    var jsonMessage = Encoding.UTF8.GetString(eventBytes);

                    var msgObj = JsonConvert.DeserializeObject<MessageType>(jsonMessage);
                    msgObj.score = await GetSentimentScore(msgObj.message);
                    var updatedEventBytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(msgObj));

                    Console.WriteLine("Message Received. Partition '{0}', SessionID '{1}' Data '{2}'", context.Lease.PartitionId, eventData.Properties["SessionId"], jsonMessage);

                    //Send to topic
                    BrokeredMessage chatMessage = new BrokeredMessage(updatedEventBytes);
                    EventData updatedEventData = new EventData(updatedEventBytes);
                    foreach (var prop in eventData.Properties)
                    {
                        chatMessage.Properties.Add(prop.Key, prop.Value);
                        updatedEventData.Properties.Add(prop.Key, prop.Value);
                    }
                    _topicClient.Send(chatMessage);
                    Console.WriteLine("Forwarded message to topic.");

                    //Send to next EventHub
                    _eventHubClient.Send(updatedEventData);
                    Console.WriteLine("Forwarded message to event hub.");
                }
                catch (Exception ex)
                {
                    LogError(ex.Message);
                }
            }

            if (_checkpointStopWatch.Elapsed > TimeSpan.FromSeconds(5))
            {
                await context.CheckpointAsync();
                _checkpointStopWatch.Restart();
            }
        }

        //{"documents":[{"score":0.8010351,"id":"1"}],"errors":[]}
        class SentimentResponse
        {
            public SentimentResponseDocument[] documents;
            public string[] errors;
        }
        class SentimentResponseDocument
        {
            public double score;
            public string id;
        }

        class SentimentRequest
        {
            public SentimentDocument[] documents;
        }

        class SentimentDocument
        {
            public string id;
            public string text;
        }

        private async Task<double> GetSentimentScore(string messageText)
        {
            double sentimentScore = -1;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_textAnalyticsBaseUrl);
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _textAnalyticsAccountKey);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var req = new SentimentRequest()
                {
                    documents = new SentimentDocument[]
                    {
                        new SentimentDocument() { id = "1", text = messageText }
                    }
                };

                var jsonReq = JsonConvert.SerializeObject(req);

                byte[] byteData = Encoding.UTF8.GetBytes(jsonReq);

                // Detect sentiment
                string uri = "sentiment";
                var response = await CallEndpoint(client, uri, byteData);
                Console.WriteLine("\nDetect sentiment response:\n" + response);
                var result = JsonConvert.DeserializeObject<SentimentResponse>(response);
                sentimentScore = result.documents[0].score;
            }
            return sentimentScore;
        }

        static async Task<String> CallEndpoint(HttpClient client, string uri, byte[] byteData)
        {
            using (var content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = await client.PostAsync(uri, content);
                return await response.Content.ReadAsStringAsync();
            }
        }

        private static void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("{0} > Exception {1}", DateTime.Now, message);
            Console.ResetColor();
        }
    }
}